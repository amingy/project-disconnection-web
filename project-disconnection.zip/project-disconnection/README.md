# project-disconnection
This website is made for Project (Dis)connection: an independent psychology
research project that focuses on parent-child relationships in Chinese-American
immigrant families. This project was run by Angela Yang and was funded by
the Stanford Chappell Lougee Scholarship.
