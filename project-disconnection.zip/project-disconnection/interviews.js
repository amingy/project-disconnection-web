function togglePopup(id) {
    document.getElementById(id).classList.toggle("active");
}